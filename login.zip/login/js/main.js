$(document).ready(function () {

    $(".button").click(function () {
        $(".input6").val($(".div1").width());
        // console.log($(this).width());
        
    });
    $(".button").click(function () {
        $(".input7").val($(".div1").height());
       
        
    });
    $(".button").click(function () {
        $(".input8").val($(".div1").outerWidth());
       
        
    });

    $(".h3").click(function() {
        $(".lorem").text("haneen edwan");
        
    } );
    $(".p").click(function() {
        $(".lor").text("lLorem ipsum dolor, sit amet consectetur adipisicing elit.");
        
    } );
    // $(".hide").click(function() {
    //     $(".div1").hide(2000,function () {
    //         $(".div1").show(2000); 

            $(".hide").click(function() {
                $(".div1").hide(2000); 
        });
        
    
    $(".show").click(function() {
        $(".div1").show(2000);
        
    } );
    $(".toggle").dblclick(function() {
        $(".div1").toggle(2000);
        
    } );

   

  $(".div1").hover(function() {

    $(this).css("background","orange") 
  }, function () {
    $(this).css("background","white")
         $(this).css("border","5px solid orange")
        $(this).css("transform"," rotate(20deg)")
  });
    
  $(".css").click(function(){
    var color=$(".input1").val();
     var border=$(".input2").val();
     var back=$(".input3").val();
     var margin=$(".input4").val();
     var padding=$(".input5").val();
   
    $("div").css({color:color,
    border:border,
    backgroundColor:back,
    margin:margin,
    padding:padding
});


   
});

 
    
 




});